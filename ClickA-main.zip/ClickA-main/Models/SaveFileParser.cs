﻿namespace ClickA.Models
{
    public class SaveFileParser
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Energy { get; set; }
        public string Clickpower { get; set; }
        public string Generator { get; set; }
        public string Transformer { get; set; }
        public string Clickbotfabrik { get; set; }
        public string Clickbot { get; set; }
    }
}
