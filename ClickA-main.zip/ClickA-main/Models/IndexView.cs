﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClickA.Models
{
    public class IndexView
    {
        public SaveFileParser Sfp { get; set; }
        public bool Message { get; set; } = false;
    }
}
