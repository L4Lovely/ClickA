﻿namespace ClickA.Models
{
    public class SessionHandler
    {
        public string username { get; set; }
        public int currency    { get; set; }
    }
}
