# ClickA
 Clicker with A -  A is for ACTION!
